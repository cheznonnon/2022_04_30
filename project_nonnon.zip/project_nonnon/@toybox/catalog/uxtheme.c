



#include "../../nonnon/win32/win.c"
#include "../../nonnon/win32/win_button.c"

#include "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_posix_char *iconname = n_posix_literal( "../../orangecat/rc/orangecat.multi.ico" );


	const int sx = 40;
	const int sy = 40;


	const int txtmax = 5;
	const int icomax = 4;

	static n_win_button htxt[ 5 ];
	static n_win_button hico[ 4 ];
	static HWND         hgui_ico;


	int i;


	switch( msg ) {


	case WM_CREATE :


		// Window

		n_project_darkmode();
n_win_fluent_ui_onoff = n_posix_false;

		n_win_init_literal( hwnd, "Nonnon", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 200,240, N_WIN_SET_CENTERING );


		// Controls

		i = 0;
		while( 1 )
		{

			n_win_button_zero( &htxt[ i ] );

			if ( i == 0 )
			{
				n_win_button_init_literal( &htxt[ i ], hwnd, "Normal"  , PBS_NORMAL );
			} else
			if ( i == 1 )
			{
				n_win_button_init_literal( &htxt[ i ], hwnd, "Hovered ", PBS_NORMAL );
			} else
			if ( i == 2 )
			{
				n_win_button_init_literal( &htxt[ i ], hwnd, "Focused" , PBS_NORMAL );
			} else
			if ( i == 3 )
			{
				n_win_button_init_literal( &htxt[ i ], hwnd, "Pressed" , PBS_PRESSED  );
			} else
			if ( i == 4 )
			{
				n_win_button_init_literal( &htxt[ i ], hwnd, "Disabled", PBS_DISABLED );
			}// else

			n_win_move_simple( htxt[ i ].hwnd, 0, i * sy, 200,sy, n_true );


			i++;
			if ( i >= txtmax ) { break; }
		}


		i = 0;
		while( 1 )
		{

			n_win_button_zero( &hico[ i ] );
			n_win_button_init( &hico[ i ], hwnd, N_STRING_EMPTY, PBS_NORMAL );

			hico[ i ].hicon = n_win_icon_init( iconname, 0, N_WIN_ICON_INIT_OPTION_DEFAULT );;

			n_win_move_simple( hico[ i ].hwnd, sx * i,sy * txtmax, sx,sy, n_true );

			i++;
			if ( i >= icomax ) { break; }
		}


		n_win_gui_literal( hwnd, ICOBTN, iconname, &hgui_ico );
		n_win_move_simple( hgui_ico, sx * i,sy * txtmax, sx,sy, n_true );

		n_win_icon_set( hgui_ico, n_win_icon_init( iconname, 0, N_WIN_ICON_INIT_OPTION_DEFAULT ) );


		// Flavor

		htxt[ 2 ].default_onoff = n_posix_true;
		hico[ 1 ].default_onoff = n_posix_true;


		// [!] : see nonnon/win32/win_button.c : n_win_button_draw()
		n_win_property_set_literal( hico[ 2 ].hwnd, "DrawState", n_true );

		n_win_button_grayed_onoff( &hico[ 2 ], n_true );
		n_win_button_grayed_onoff( &hico[ 3 ], n_true );

		EnableWindow( hgui_ico, n_false );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :
	{
		ShowWindow( hwnd, SW_HIDE );

		i = 0;
		while( 1 )
		{

			n_win_button_exit( &htxt[ i ] );

			i++;
			if ( i >= txtmax ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_win_button_exit( &hico[ i ] );

			i++;
			if ( i >= icomax ) { break; }
		}

		DestroyWindow( hwnd );
	}
	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	i = 0;
	while( 1 )
	{

		n_win_button_proc( hwnd, msg, wparam, lparam, &htxt[ i ] );

		i++;
		if ( i >= txtmax ) { break; }
	}

	i = 0;
	while( 1 )
	{

		n_win_button_proc( hwnd, msg, wparam, lparam, &hico[ i ] );

		i++;
		if ( i >= icomax ) { break; }
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

