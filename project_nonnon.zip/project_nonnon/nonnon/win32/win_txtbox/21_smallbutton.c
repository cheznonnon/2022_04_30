// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define n_win_txtbox_smallbutton_direct_embed(     p, sb, i ) n_win_txtbox_smallbutton_direct_main( p, sb, i, n_posix_true  )
#define n_win_txtbox_smallbutton_direct_rearrange( p, sb, i ) n_win_txtbox_smallbutton_direct_main( p, sb, i, n_posix_false )

// internal
void
n_win_txtbox_smallbutton_direct_main( n_win_txtbox *p, n_win_smallbutton_direct *sb, int index, n_posix_bool is_init )
{
//return;

	if ( p == NULL ) { return; }


	if ( ( index < 0 )||( index >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) ) { return; }


	if ( is_init )
	{
		p->smallbutton_is_used = n_posix_true;
		n_win_timer_init( p->hwnd, p->smallbutton_timer, 33 );
	}


	p->smallbutton[ index ] = sb;


	if ( is_init )
	{
		n_win_txtbox_metrics( p );
	}


	index = n_posix_max( 1, index + 1 );

	n_type_gfx ix,iy,isx,isy; n_win_location( p->hwnd, &ix,&iy,&isx,&isy );

	ix = iy = 0;

	{

		const n_type_gfx border = 2 * p->scale;

		n_type_gfx btn = isy - ( border * 2 );

		//if ( p->debug_onoff == n_posix_false )
		{
			n_type_gfx bx = bx = ( ix + isx ) - border - ( btn * index );
			n_type_gfx by = iy + border;

			sb->x  = bx;
			sb->y  = by;
			sb->sx = btn;
			sb->sy = btn;

			sb->old_x  = sb->x;
			sb->old_y  = sb->y;
			sb->old_sx = sb->sx;
			sb->old_sy = sb->sy;

			sb->x  += p->border_pxl_sx;
			sb->y  += p->border_pxl_sx;
			sb->sx -= p->border_pxl_sx * 2;
			sb->sy -= p->border_pxl_sy * 2;

			sb->bmp_canvas = &p->bmp;

//if ( index == 0 ) { n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", sb->x, sb->y, sb->sx, sb->sy ); }
		}

		p->smallbutton_margin = btn * index;

	}


	return;
}

n_posix_bool
n_win_txtbox_smallbutton_direct_is_hovered( n_win_txtbox *p )
{
//return 0;

	n_posix_bool ret = n_posix_false;

	int i = 0;
	while( p->smallbutton_is_used )
	{//break;

		n_win_smallbutton_direct *sb = p->smallbutton[ i ];

		if ( sb != NULL )
		{
			if ( sb->show_onoff )
			{
				if ( sb->state & N_WIN_SMALLBUTTON_DIRECT_HOVERED )
				{
					ret = n_posix_true;
					break;
				}
			}
		}

		i++;
		if ( i >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) { break; }
	}


	return ret;
}

void
n_win_txtbox_smallbutton_direct_fade( n_win_txtbox *p, n_posix_bool onoff )
{
//return;

	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_CMB_BOX ) ) { return; }

	if ( p->style & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE ) { return; }


	int i = 0;
	while( p->smallbutton_is_used )
	{//break;

		n_win_smallbutton_direct *sb = p->smallbutton[ i ];

		if ( sb != NULL )
		{
			if ( sb->show_onoff )
			{
				n_win_smallbutton_direct_bitmap_init( sb );

				if ( p->smallbutton_once )
				{
					n_bmp_fade_init( &sb->fade, sb->color_fg      );
				} else {
					if ( onoff )
					{
						n_bmp_fade_init( &sb->fade, sb->color_fg      );
					} else {
						n_bmp_fade_init( &sb->fade, sb->color_hovered );
					}

					sb->fade.percent =   0;
					sb->fade_blend   = 0.0;
					//sb->fade.stop    = n_posix_true;

					n_win_smallbutton_direct_bitmap_draw( sb );
				}
			}
		}

		i++;
		if ( i >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) { break; }
	}


	return;
}

void
n_win_txtbox_smallbutton_aero_combo( n_win_txtbox *p, u32 color, u32 color_mix, double blend )
{
//return;

	if ( p->smallbutton_is_used == n_posix_false ) { return; }


	u32 box_u = color;
	u32 box_d = color;

	if ( p->aero_combo_onoff )
	{
		box_u = n_bmp_blend_pixel( color, color_mix, blend );
	}

//box_u = box_d = n_bmp_rgb( 0,200,255 );

	int i = 0;
	while( 1 )
	{

		n_win_smallbutton_direct *sb = p->smallbutton[ i ];

		if ( sb != NULL )
		{
			sb->color_box_u = box_u;
			sb->color_box_d = box_d;
		}

		i++;
		if ( i >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) { break; }
	}


	return;
}
/*
void
n_win_txtbox_smallbutton_refresh( n_win_txtbox *p )
{

	// [x] : WIn8.1 or later : don't use this : background color will be white

	return;

	if ( p->smallbutton_is_used == n_posix_false ) { return; }


	HDC hdc_main = GetDC( p->hwnd );
	HDC hdc_cmpt = CreateCompatibleDC( hdc_main );

	HBITMAP hbmp_old = SelectObject( hdc_cmpt, p->hbmp );


	int i = 0;
	while( 1 )
	{//break;

		n_win_smallbutton_direct *sb = p->smallbutton[ i ];

		if ( sb != NULL )
		{
			if ( sb->show_onoff )
			{
				n_win_box( p->hwnd, hdc_main, NULL, 0 );
				BitBlt( hdc_main, sb->x,sb->y,sb->sx,sb->sy, hdc_cmpt, sb->x,sb->y, SRCCOPY );
			}
		}

		i++;
		if ( i >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) { break; }
	}


	SelectObject( hdc_cmpt, hbmp_old );

	DeleteObject( hdc_cmpt );
	ReleaseDC( p->hwnd, hdc_main );


	return;
}
*/

