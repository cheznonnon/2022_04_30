// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define n_win_txtbox_hwndprintf(         p, f, ... ) n_win_hwndprintf( n_win_hwnd_toplevel( ( p )->hwnd ), f, ##__VA_ARGS__ )
#define n_win_txtbox_hwndprintf_literal( p, f, ... ) n_win_txtbox_hwndprintf( p, n_posix_literal( f ), ##__VA_ARGS__ )
#define n_win_txtbox_debug_count(        p         ) n_win_debug_count( n_win_hwnd_toplevel( ( p )->hwnd ) )




//static n_win_txtbox *n_win_txtbox_debug_instance = NULL;



#define N_WIN_TXTBOX_GRAYED                 (  1 )
#define N_WIN_TXTBOX_METRICS_MAXWIDTH       (  2 )
#define N_WIN_TXTBOX_STR2INDEX              (  3 )
#define N_WIN_TXTBOX_REFRESH_OPTIMIZED_EXIT (  4 )
#define N_WIN_TXTBOX_MENU_UNDO              (  5 )
#define N_WIN_TXTBOX_MENU_CUT               (  6 )
#define N_WIN_TXTBOX_MENU_COPY              (  7 )
#define N_WIN_TXTBOX_MENU_DELETE            (  8 )
#define N_WIN_TXTBOX_MENU_PASTE             (  9 )
#define N_WIN_TXTBOX_MENU_SELECTALL         ( 10 )
#define N_WIN_TXTBOX_MENU_LINENUM           ( 11 )
#define N_WIN_TXTBOX_CARET_ON_TIMER         ( 12 )
#define N_WIN_TXTBOX_WM_IME_COMPOSITION     ( 13 )
#define N_WIN_TXTBOX_WM_MOUSEWHEEL          ( 14 )
#define N_WIN_TXTBOX_WM_MOUSEMOVE           ( 15 )
#define N_WIN_TXTBOX_WM_LBUTTONDOWN         ( 16 )
#define N_WIN_TXTBOX_WM_LBUTTONDBLCLK       ( 17 )
#define N_WIN_TXTBOX_WM_LBUTTON_TRIPLE      ( 18 )
#define N_WIN_TXTBOX_WM_TIMER               ( 19 )
#define N_WIN_TXTBOX_WM_TIMER_MOUSE         ( 20 )
#define N_WIN_TXTBOX_WM_MBUTTONUP           ( 21 )
#define N_WIN_TXTBOX_WM_IME_REQUEST         ( 22 )
#define N_WIN_TXTBOX_WM_SETFOCUS            ( 23 )
#define N_WIN_TXTBOX_WM_KILLFOCUS           ( 24 )
#define N_WIN_TXTBOX_WM_COMMAND             ( 25 )
#define N_WIN_TXTBOX_WM_KEYDOWN             ( 26 )
#define N_WIN_TXTBOX_WM_SIZE                ( 27 )
#define N_WIN_TXTBOX_PROC_WM_DRAWITEM       ( 28 )
#define N_WIN_TXTBOX_PROC_WM_PRINTCLIENT    ( 29 )
#define N_WIN_TXTBOX_IME_FADE               ( 30 )
#define N_WIN_TXTBOX_EDIT_ON_TYPING         ( 31 )
#define N_WIN_TXTBOX_COMBOBOX               ( - 1 )
#define N_WIN_TXTBOX_CATPAD_UI_REFRESH      ( - 2 )
#define N_WIN_TXTBOX_CATPAD_SYNC            ( - 3 )
#define N_WIN_TXTBOX_CATPAD_SEARCH          ( - 4 )
#define N_WIN_TXTBOX_NEKO_NO_TE             ( - 5 )
#define N_WIN_TXTBOX_NMEMO                  ( - 6 )
#define N_WIN_TXTBOX_NONNON_PAINT           ( - 7 )
#define N_WIN_TXTBOX_ORANGECAT              ( - 8 )
#define N_WIN_TXTBOX_PROJECTCHECKER         ( - 9 )
#define N_WIN_TXTBOX_WATCHCAT               ( -10 )

n_posix_bool
n_win_txtbox_debug_enabled_id( n_win_txtbox *p, int id )
{
return n_posix_false;

	//if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { return n_posix_false; }

	//if ( id == N_WIN_TXTBOX_REFRESH_OPTIMIZED_EXIT ) { return n_posix_false; }
	if ( id == N_WIN_TXTBOX_CARET_ON_TIMER         ) { return n_posix_false; }
	//if ( id == N_WIN_TXTBOX_WM_MOUSEWHEEL          ) { return n_posix_false; }
	//if ( id == N_WIN_TXTBOX_WM_TIMER_MOUSE         ) { return n_posix_false; }
	//if ( id == N_WIN_TXTBOX_WM_KEYDOWN             ) { return n_posix_false; }
	//if ( id == N_WIN_TXTBOX_PROC_WM_DRAWITEM       ) { return n_posix_false; }
	//if ( id == N_WIN_TXTBOX_IME_FADE               ) { return n_posix_false; }
	//if ( id == N_WIN_TXTBOX_ORANGECAT              ) { return n_posix_false; }

	return n_posix_true;
}

void
n_win_txtbox_refresh( n_win_txtbox *p, int id )
{
if ( n_win_txtbox_debug_enabled_id( p, id ) ) { n_win_txtbox_hwndprintf_literal( p, " Refresh : %d ", id ); }

	n_win_refresh( p->hwnd, n_posix_false );

	return;
}




void
n_win_txtbox_debug_partial_selection( n_win_txtbox *p )
{

	n_posix_debug_literal
	(
		"From %d %d\n"
		"To   %d %d\n"
		"%d %d",
		p->partial_selection_from_onoff, p->partial_selection_from_cch_x,
		p->partial_selection_to___onoff, p->partial_selection_to___cch_x,
		p->select_cch_x, p->select_cch_sx
	);

	return;
}

void
n_win_txtbox_debug_keycode( n_win_txtbox *p, int vk )
{

	if ( vk == VK_UP )
	{
		n_win_txtbox_hwndprintf_literal( p, " VK_UP : %d ", vk );
	} else
	if ( vk == VK_DOWN )
	{
		n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : %d ", vk );
	} else
	if ( vk == VK_LEFT )
	{
		n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : %d ", vk );
	} else
	if ( vk == VK_RIGHT )
	{
		n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %d ", vk );
	}


	return;
}




void
n_win_txtbox_message_redirect( n_win_txtbox *p, HWND hwnd, UINT msg )
{

	if ( n_win_is_hovered( p->hwnd ) )
	{
		n_win_message_send( hwnd, WM_COMMAND, msg, p->hwnd );
	}


	return;
}


