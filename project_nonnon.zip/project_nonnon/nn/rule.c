// Nekomimi Nina
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Mechanism]
//
//	A : prm3 : NPC starting position and movement
//	R : prm2 : 0 means "wall"
//	G : prm1 : event number
//	B : chip : chip  number




// Phase

#define N_NN_RULE_PHASE_MAX 1

void
n_nn_rule_phase_load( n_nn *p, n_bmp *bmp_main )
{

	int loop = N_GAME_MAP_MODE_XLOOP;
	if ( p->player == N_NN_PLAYER_NINA ) { loop = N_GAME_MAP_MODE_STOP; }


	n_posix_char name_map[ 100 ];
	n_posix_char name_chp[ 100 ];

	int i = 0;
	while( 1 )
	{

		n_game_map *m = &p->map[ i ];


		n_posix_sprintf_literal( name_map, "NN_MAP_%d_%d", p->phase, i );
		n_posix_sprintf_literal( name_chp, "NN_MAP_%d_C",  p->phase    );

		n_game_map_init
		(
			m,
			name_map, name_chp,
			p->unit, p->unit,
			loop | N_GAME_MAP_MODE_TRANS,
			bmp_main
		);


		n_bmp_scaler_big( &m->chip, p->zoom );

		m->chip_sx  = N_BMP_SX( &m->chip ) / p->unit;
		m->chip_sy  = N_BMP_SY( &m->chip ) / p->unit;
		m->chip_max = m->chip_sx * m->chip_sy;


		i++;
		if ( i >= N_NN_MAP_MAX ) { break; }
	}


	return;
}




// Event

#define N_NN_RULE_CHIP_EMPTY 255
#define N_NN_RULE_CHIP_NEKO    5
#define N_NN_RULE_CHIP_DOKAN   7

#define N_NN_RULE_INIT_BASE  200
#define N_NN_RULE_WARP_BASE  150
#define N_NN_RULE_WARP_COUNT   7
#define N_NN_RULE_WARP_MAX   ( N_NN_RULE_WARP_COUNT + 1 )

#define n_nn_rule_is_empty(      p ) ( N_NN_RULE_CHIP_EMPTY == n_nn_rule_chip( p ) )
#define n_nn_rule_is_neko(       p ) ( N_NN_RULE_CHIP_NEKO  == ( n_nn_rule_chip( p ) % (p)->map[ N_NN_MAP_MAIN ].chip_sx ) )
#define n_nn_rule_is_dokan(      p ) ( N_NN_RULE_CHIP_DOKAN == ( n_nn_rule_chip( p ) % (p)->map[ N_NN_MAP_MAIN ].chip_sx ) )
#define n_nn_rule_is_dokan_main( p ) ( 207 == n_nn_rule_chip( p ) )

void
n_nn_rule_autoset( n_nn *p, int character_number )
{

	if ( character_number == N_NN_CHR_PLAYER )
	{
		n_game_map_chara_autoset( &p->mch[ character_number ], 1, N_NN_RULE_INIT_BASE + p->event );
	} else {
		n_game_map_chara_autoset( &p->mch[ character_number ], 3, 100 + character_number );
	}


	return;
}

#define n_nn_rule_is_movable( p, n ) n_nn_rule_is_movable_offset( p, n, 0, 0 )

n_bool
n_nn_rule_is_movable_offset( n_nn *p, int character_number, n_type_gfx ox, n_type_gfx oy )
{

	n_bool ret = n_false;


	if ( character_number == N_NN_CHR_PLAYER )
	{

		//

	} else {

		n_game_map_chara *mc = &p->mch[ character_number ];

		int number = n_game_map_prm3_get( n_game_map_get( mc->m, mc->c->x + ox, mc->c->y + oy ) );

		ret = ( ( 100 <= number )&&( number <= ( 100 + N_NN_NPC_MAX ) ) );

	}


	return ret;
}

u32
n_nn_rule_data( n_nn *p )
{

	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];
	n_game_chara     *c  =  mc->c;
	n_game_map       *m  =  mc->m;


	n_type_gfx x = c->x + ( c->sx / 2 );
	n_type_gfx y = c->y + ( c->sy / 2 );


	return n_game_map_get( m, x,y );
}

u32
n_nn_rule_data_map( n_nn *p, n_game_map *m )
{

	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];
	n_game_chara     *c  =  mc->c;


	n_type_gfx x = c->x + ( c->sx / 2 );
	n_type_gfx y = c->y + ( c->sy / 2 );


	return n_game_map_get( m, x,y );
}

int
n_nn_rule_event( n_nn *p )
{

	u32 data = n_nn_rule_data( p );


	return n_game_map_prm1_get( data ) - N_NN_RULE_WARP_BASE;
}

int
n_nn_rule_chip( n_nn *p )
{

	u32 data = n_nn_rule_data( p );


	return n_game_map_chip_get( data );
}

int
n_nn_rule_is_warp( n_nn *p )
{

	int event = n_nn_rule_event( p );


	return ( ( event >= 0 )&&( event < N_NN_RULE_WARP_MAX ) );
}

#define N_NN_RULE_IS_DOKAN_LR_LEFT  ( 100 )
#define N_NN_RULE_IS_DOKAN_LR_RIGHT ( 150 )

int
n_nn_rule_is_dokan_left_right( n_nn *p )
{
	return n_game_map_prm1_get( n_nn_rule_data_map( p, &p->map[ N_NN_MAP_FG_2 ] ) );
}

n_bool
n_nn_rule_is_dokan_exit( n_nn *p )
{

	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];
	n_game_chara     *c  =  mc->c;


	n_type_gfx x = c->x + ( c->sx / 2 );
	n_type_gfx y = c->y + ( c->sy * 2 );


	u32 data = n_game_map_get( &p->map[ N_NN_MAP_FG_2 ], x,y );
	int chip = n_game_map_chip_get( data );
//n_game_hwndprintf_literal( " %d ", data );


	return ( ( chip == 35 )||( chip == 36 ) );
}

int
n_nn_rule_event2transition( n_nn *p )
{

	const int count = N_GAME_TRANSITION_LAST;

	const int type[] = {

		N_GAME_TRANSITION_WIPE_Y,
		N_GAME_TRANSITION_WIPE_X,
		N_GAME_TRANSITION_SHUTTER,
		N_GAME_TRANSITION_INFLATE,
		N_GAME_TRANSITION_CIRCLE,
		N_GAME_TRANSITION_FADE,
		N_GAME_TRANSITION_DIZZY,
		N_GAME_TRANSITION_WHIRL,
		N_GAME_TRANSITION_MOSAIC,
		N_GAME_TRANSITION_SCROLL_U,
		N_GAME_TRANSITION_SCROLL_D,
		N_GAME_TRANSITION_SCROLL_L,
		N_GAME_TRANSITION_SCROLL_R,

	};

	static int index = 0;


	int ret = type[ index ];


	// [!] : shuffle

	while( 1 )
	{
		index = n_game_random( count );
		if ( ret != type[ index ] ) { break; }
	}

	//index++;
	//if ( index >= count ) { index = 0; }


	return ret;
}

